﻿附录

以下是该驱动程序所含许可模块的列表。

附件 1（该驱动程序的软件程序）


libcnbpcnclapi*.so. ?.?.?
libcnbpnet20.so.?.?.?
libcnbpnet30.so.?.?.?
libcnnet*.so.?.?.?
cnnet.ini
cnb_*.res
autoalign.utl
cleaning.utl
nozzlecheck.utl


附件 2（GNU General Public License Version 2许可的免费软件组件）


*.ppd
cnijfilter2-*-pkgconfig.sh
cnijbe*
cnijlgmon3.mo
rastertocanonij
tocnpwg


附件 3


cnijlgmon3
cmdtocanonij2
cmdtocanonij3
tocanonij
