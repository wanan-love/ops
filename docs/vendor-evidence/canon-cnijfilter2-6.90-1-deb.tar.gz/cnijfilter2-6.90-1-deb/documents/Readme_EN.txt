﻿Appendix

A list of the license modules including in this driver is indicated below.

Exhibit 1 (The software programs of this driver)


libcnbpcnclapi*.so. ?.?.?
libcnbpnet20.so.?.?.?
libcnbpnet30.so.?.?.?
libcnnet*.so.?.?.?
cnnet.ini
cnb_*.res
autoalign.utl
cleaning.utl
nozzlecheck.utl


Exhibit 2 (The free software components licensed under GNU General Public License Version 2)


*.ppd
cnijfilter2-*-pkgconfig.sh
cnijbe*
cnijlgmon3.mo
rastertocanonij
tocnpwg


Exhibit 3


cnijlgmon3
cmdtocanonij2
cmdtocanonij3
tocanonij
