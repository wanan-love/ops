﻿付録

このドライバーに含まれるライセンスモジュールの一覧を示します。

Exhibit 1（このドライバーのソフトウェア）


libcnbpcnclapi*.so. ?.?.?
libcnbpnet20.so.?.?.?
libcnbpnet30.so.?.?.?
libcnnet*.so.?.?.?
cnnet.ini
cnb_*.res
autoalign.utl
cleaning.utl
nozzlecheck.utl


Exhibit 2（GNU General Public License Version 2に基づき許諾されるフリーソフトウェアモジュール）


*.ppd
cnijfilter2-*-pkgconfig.sh
cnijbe*
cnijlgmon3.mo
rastertocanonij
tocnpwg


Exhibit 3


cnijlgmon3
cmdtocanonij2
cmdtocanonij3
tocanonij
