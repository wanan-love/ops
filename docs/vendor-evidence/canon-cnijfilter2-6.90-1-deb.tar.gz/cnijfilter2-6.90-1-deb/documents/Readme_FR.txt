﻿Annexe

Une liste des modules sous licence inclus dans ce pilote se trouve ci-dessous.

Annexe 1 (Les programmes logiciels de ce pilote)


libcnbpcnclapi*.so. ?.?.?
libcnbpnet20.so.?.?.?
libcnbpnet30.so.?.?.?
libcnnet*.so.?.?.?
cnnet.ini
cnb_*.res
autoalign.utl
cleaning.utl
nozzlecheck.utl


Annexe 2 (Les composants logiciels gratuits sous licence dans General Public License Version 2 GNU)


*.ppd
cnijfilter2-*-pkgconfig.sh
cnijbe*
cnijlgmon3.mo
rastertocanonij
tocnpwg


Annexe 3


cnijlgmon3
cmdtocanonij2
cmdtocanonij3
tocanonij
